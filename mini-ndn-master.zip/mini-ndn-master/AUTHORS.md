Mini-NDN Authors
================

Mini-NDN is an open source project that includes contributions from the following individuals.

## Mini-NDN contributors and affiliations:

* The University of Memphis

    * Ashlesh Gawande <agawande@memphis.edu>
    * Vince Lehman    <http://vslehman.com>
    * Yucheng Zhang   <yzhang@memphis.edu>
    * Lan Wang        <http://www.cs.memphis.edu/~lanwang/>

* The University of Arizona

    * Junxiao Shi    <http://www.cs.arizona.edu/people/shijunxiao/>
    * Beichuan Zhang <http://www.cs.arizona.edu/~bzhang/>

* University of California, Los Angeles

    * Alexander Afanasyev <http://lasr.cs.ucla.edu/afanasyev/index.html>

## The Mini-CCNx team:

* University of Campinas

    * Caio de Moraes Elias
    * Carlos Cabral
    * Christian Esteve Rothenberg
